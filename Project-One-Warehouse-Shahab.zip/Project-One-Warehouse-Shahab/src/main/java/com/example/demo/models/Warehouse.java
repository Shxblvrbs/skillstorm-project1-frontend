package com.example.demo.models;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.example.demo.dtos.WarehouseDto;

/*
 * Warehouse represents a physical location where products are stored
 */

@Entity
@Table(name = "Warehouse")
public class Warehouse {
   
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Warehouse_ID")
    private Long id;
    
    @Column
    private String name;
    
    @Column 
    private String location;
    
    @Column
    private String description;
    
    public Warehouse() {
    	
    }

	public Warehouse(Long id, String name, String location, String description) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public WarehouseDto toDto() {
		return new WarehouseDto(id, name, location, description);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Warehouse other = (Warehouse) obj;
		return Objects.equals(id, other.id);
	}
    
}