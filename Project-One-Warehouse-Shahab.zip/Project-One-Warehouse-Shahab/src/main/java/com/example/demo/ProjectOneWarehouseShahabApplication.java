package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectOneWarehouseShahabApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectOneWarehouseShahabApplication.class, args);
	}

}
