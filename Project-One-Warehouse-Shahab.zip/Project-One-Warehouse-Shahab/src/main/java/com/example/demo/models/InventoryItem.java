package com.example.demo.models;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.example.demo.dtos.InventoryItemDto;

@Entity
public class InventoryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Inventory_Item_ID")
    private Long id;

    @Column
    private Integer quantity;
    
    @ManyToOne
    @JoinColumn(name = "Warehouse_ID")
    private Warehouse warehouse;
    
    @ManyToOne
    @JoinColumn(name = "Product_ID")
    private Product product;
    
    public InventoryItem() {
    	
    }

	public InventoryItem(Long id, Integer quantity, Warehouse warehouse, Product product) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.warehouse = warehouse;
		this.product = product;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Warehouse getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public InventoryItemDto toDto() {
		return new InventoryItemDto(id, quantity, warehouse.getId(), product.getId());
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InventoryItem other = (InventoryItem) obj;
		return Objects.equals(id, other.id);
	}
	
    
}
