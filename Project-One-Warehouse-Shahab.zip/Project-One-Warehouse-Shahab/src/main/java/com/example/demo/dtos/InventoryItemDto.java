package com.example.demo.dtos;

import java.util.Objects;

public class InventoryItemDto {

	private Long id;
	private Integer quantity;
	private Long warehouseId;
	private Long productId;
	
	public InventoryItemDto() {
		
	}
	
	public InventoryItemDto(Long id, Integer quantity, Long warehouseId, Long productId) {
		super();
		this.id = id;
		this.warehouseId = warehouseId;
		this.productId = productId;
		this.quantity = quantity;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Long warehouseId) {
		this.warehouseId = warehouseId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, productId, quantity, warehouseId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InventoryItemDto other = (InventoryItemDto) obj;
		return Objects.equals(id, other.id) && Objects.equals(productId, other.productId)
				&& Objects.equals(quantity, other.quantity) && Objects.equals(warehouseId, other.warehouseId);
	}

	@Override
	public String toString() {
		return "InventoryItemDto [id=" + id + ", productId=" + productId + ", warehouseId=" + warehouseId
				+ ", quantity=" + quantity + "]";
	}
	
	
	
}
