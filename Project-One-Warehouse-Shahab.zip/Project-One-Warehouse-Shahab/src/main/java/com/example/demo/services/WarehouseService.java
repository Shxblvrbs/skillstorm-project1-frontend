package com.example.demo.services;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dtos.WarehouseDto;
import com.example.demo.models.Warehouse;
import com.example.demo.repositories.WarehouseRepository;

@Service
public class WarehouseService {

	@Autowired
	private WarehouseRepository warehouseRepository;
	
	public List<WarehouseDto> findAllWarehouses() {
		//List<WarehouseDto> newList = new LinkedList<>();
		//for (Warehouse w : warehouseRepository.findAll()) {
		//	newList.add(w.toDto());
		//}
		//return newList;
		return warehouseRepository.findAll()
				.stream()
				.map(w -> w.toDto())
				.toList();
		
	}
	
	public WarehouseDto findWarehouseById(Long id) {
		return warehouseRepository.findById(id)
				.orElseThrow()
				.toDto();
	}
	
	/**
	 * 
	 * @param warehouseData: The data to create a warehouse entity with
	 * @return The data of the newly created Warehouse
	 */
	public WarehouseDto createWarehouse(WarehouseDto warehouseData) {
		Warehouse warehouse = new Warehouse(warehouseData.getId(), warehouseData.getName(), warehouseData.getLocation(), warehouseData.getDescription()); 
		return warehouseRepository.save(warehouse).toDto();
	}
}
